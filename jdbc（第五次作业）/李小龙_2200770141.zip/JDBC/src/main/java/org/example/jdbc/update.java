package org.example.jdbc;

import java.sql.*;

public class update {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        //更新数据库sql语句
        String sql = "UPDATE teacher SET name = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {//建立连接
            conn.setAutoCommit(false);//取消自动提交
            try (PreparedStatement ps = conn.prepareStatement(sql);) {//设置预执行语句
                // 设置参数
                ps.setString(1, "蔡徐坤");
                ps.setInt(2, 1);
                // 执行插入或更新
                ps.executeUpdate();
                conn.commit();
                System.out.println("修改成功");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
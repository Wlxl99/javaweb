package org.example.jdbc;

import java.sql.*;

public class insert {
    public static void main(String[] args){
        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        //向teacher表插入数据的sql语句
        String sql = "INSERT INTO teacher (id,name,course,birthday) VALUES (?,?,?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {//建立连接
            conn.setAutoCommit(false);//关闭自动提交
            try (PreparedStatement ps = conn.prepareStatement(sql);) {//设置预执行语句
                // 设置参数
                ps.setInt(1, 1);
                ps.setString(2, "jkl");
                ps.setString(3, "C语言");
                ps.setDate(4, java.sql.Date.valueOf("2000-10-29"));

                // 执行插入
                ps.executeUpdate();
                conn.commit();
                System.out.println("插入成功");

            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            } finally {
                // 释放资源
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

package org.example.jdbc;

import java.sql.*;

public class scroll_outcome {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        //查询sql语句
        String sql = "SELECT * FROM teacher";

        try (Connection conn = DriverManager.getConnection(url, user, password);//建立连接
             PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);//可滚动结果集预执行指令
        ) {
            // 执行查询
            try (ResultSet rs = ps.executeQuery()) {
                // 移动到倒数第二行
                rs.absolute(-2);
                //输出倒数第二行的数据
                System.out.println(rs.getInt("id") + " " + rs.getString("name")+" "+rs.getString("course")+" "+rs.getDate("birthday"));
            }catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

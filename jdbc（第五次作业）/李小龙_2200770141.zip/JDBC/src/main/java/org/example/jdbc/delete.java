package org.example.jdbc;

import java.sql.*;

public class delete {
    public static void main(String[] args) {

        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        // 删除名字为蔡徐坤的学生
        String sql = "DELETE FROM teacher WHERE name = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {//建立连接
            conn.setAutoCommit(false);//取消自动提交
            try (PreparedStatement ps = conn.prepareStatement(sql);) {//设置预执行语句
                // 设置参数
                ps.setString(1, "蔡徐坤");
                // 执行删除
                ps.executeUpdate();
                conn.commit();
                System.out.println("删除成功");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

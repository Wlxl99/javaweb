package org.example.jdbc;

import java.sql.*;

public class batch_insert {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        //实现批量插入的sql语句
        String sql = "INSERT INTO teacher(id, name, course,birthday) VALUES(?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {//建立连接
            conn.setAutoCommit(false);//取消自动提交
            try (PreparedStatement ps = conn.prepareStatement(sql);) {//设置预执行指令
                // 设置参数
                for (int i = 1; i < 501; i++) {
                    ps.setInt(1, i);
                    ps.setString(2, "name" + i);
                    ps.setString(3, "english"+i);
                    ps.setDate(4, java.sql.Date.valueOf("2004-07-25"));
                    // 添加到批处理
                    ps.addBatch();
                    if (i % 100 == 0) { // 每100条记录执行一次批处理,并且提交一次
                        ps.executeBatch();
                        ps.clearBatch();
                        conn.commit();//每插入100条提交一次
                    }
                }
                ps.executeBatch();
                conn.commit();
                System.out.println("完成批量插入数据");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
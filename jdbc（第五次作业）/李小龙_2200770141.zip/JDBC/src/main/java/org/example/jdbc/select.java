package org.example.jdbc;

import java.sql.*;

public class select {
    public static void main(String[] args) {
        String url = "jdbc:mysql://127.0.0.1:3306/jdbc_demo?serverTimezone=GMT&characterEncoding=UTF-8";
        String user = "root";
        String password = "123456";

        //teacher表查询语句
        String sql = "select * from teacher";

        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try{
            //使用DriverManger获取数据库连接
            connection=DriverManager.getConnection(url,user,password);
            //使用Connection建立一个PreparedStatment
            ps= connection.prepareStatement(sql);
            //执行sql查询
            rs=ps.executeQuery();
            //遍历输出查询结果
            while(rs.next()){
                System.out.println(rs.getInt("id"));
                System.out.println(rs.getString("name"));
                System.out.println(rs.getString("course"));
                System.out.println(rs.getDate("birthday"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            // 释放资源
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

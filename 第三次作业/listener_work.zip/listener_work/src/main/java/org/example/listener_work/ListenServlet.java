package org.example.listener_work;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.util.logging.Logger;

@WebListener
public class ListenServlet implements ServletRequestListener {
    private static final Logger logger = Logger.getLogger(ListenServlet.class.getName());

    static {
        rizhi.setup();  // 初始化日志配置
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        request.setAttribute("startTime", System.currentTimeMillis());

        String method = request.getMethod();
        String uri = request.getRequestURI();
        String queryString = request.getQueryString();
        String clientIp = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");

        logger.info(String.format("Request Initialized - Method: %s, URI: %s, Query: %s, IP: %s, User-Agent: %s",
                method, uri, queryString != null ? queryString : "N/A", clientIp, userAgent));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = (long) request.getAttribute("startTime");
        long processingTime = System.currentTimeMillis() - startTime;

        logger.info(String.format("Request Completed - URI: %s, Processing Time: %d ms",
                request.getRequestURI(), processingTime));
    }
}
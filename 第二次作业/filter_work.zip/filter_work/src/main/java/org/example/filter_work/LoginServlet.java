package org.example.filter_work;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/login.html").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("lxl".equals(username) && "123456".equals(password)) {
            // 设置用户名到会话中
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            // 重定向到home.html
            response.sendRedirect(request.getContextPath() + "/home.html");
        } else {
            // 重定向回登录页面
            response.sendRedirect(request.getContextPath() + "/login.html");
        }
    }
}

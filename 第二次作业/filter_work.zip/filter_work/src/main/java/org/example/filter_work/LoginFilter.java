package org.example.filter_work;


import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/*")
public class LoginFilter implements Filter {

    // 排除列表，包含不需要登录就能访问的路径
    private static final List<String> EXCLUDED_PATHS = Arrays.asList(
            "/login.html",
            "/home.html",
            "login"
    );

    //初始化
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        boolean isStaticResource = EXCLUDED_PATHS.stream().anyMatch(ext->{
            System.out.println("ext:"+ext);
            return httpRequest.getRequestURI().contains(ext);
        });

        if (isStaticResource) {
            chain.doFilter(request, response);
        }else {
            String username =(String)httpRequest.getSession().getAttribute("username");
            if ("".equals(username)||username==null) {
                httpResponse.sendRedirect(httpRequest.getContextPath()+"/login.html");
            }else {
                chain.doFilter(request, response);
            }
        }

    }

    @Override
    public void destroy() {

    }

}